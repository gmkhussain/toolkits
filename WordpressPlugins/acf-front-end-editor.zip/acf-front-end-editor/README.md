# Advanced Custom Fields add-on: Front-end Editor v2.0

[![ACF FRONT END EDITOR](http://horiondigital.com/hostedimages/acffront0.png)](http://www.youtube.com/watch?v=rb9rsLaDImc)

This is an add-on for WordPress [Advanced Custom Fields plugin](https://wordpress.org/plugins/advanced-custom-fields/)

The add-on allows admins to edit text fields, textareas and wysiwyg fields from front end simillary as you would edit a google doc.

Have fun.

P.S. it also works with OPTIONS page fields, in the LOOP, with repeaters and flexible content:

[![ACF FRONT END EDITOR](http://horiondigital.com/hostedimages/acffront2.gif)](http://www.youtube.com/watch?v=rb9rsLaDImc)

Add-on author: Audrius Rackauskas @ [Horion Digital, Ltd](http://www.horiondigital.com) 

ACF plugin author: [Elliot Condon](http://www.elliotcondon.com/)