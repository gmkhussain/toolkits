<?php

abstract class PHPParser_Node_Stmt_TraitUseAdaptation extends PHPParser_Node_Stmt
{
}