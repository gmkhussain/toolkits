/*
Theme Name:     <?php echo $new_theme_title, "\n"; ?>
Template:       <?php echo $parent_template_name, "\n"; ?>

Right to Left text support.
*/
@import url("../<?php echo $rtl_theme; ?>/rtl.css");
